PyZenKit
================================================================================

Collection of usefull tools and utilities for Python 3.

.. warning::

    This library is still work in progress.

.. note::

    For usage and examples please see the source code, for demonstration execute
    the appropriate module with Python3 interpreter.

Copyright
--------------------------------------------------------------------------------

Copyright (C) since 2016 Jan Mach <honza.mach.ml@gmail.com>
Use of this package is governed by the MIT license, see LICENSE file.
